package br.com.felipeaio.CadastrodeGames;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CadastroDeGamesApplication {

	public static void main(String[] args) {
		SpringApplication.run(CadastroDeGamesApplication.class, args);
	}

}
