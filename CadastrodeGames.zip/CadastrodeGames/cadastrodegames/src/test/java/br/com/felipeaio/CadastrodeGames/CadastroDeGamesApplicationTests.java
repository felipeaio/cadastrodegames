package br.com.felipeaio.CadastrodeGames;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CadastroDeGamesApplicationTests {

	@Test
	void contextLoads() {
	}

}
